from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from .models import License, Administrator
from .serializers import LicenseSerializer, AdministratorSerializer

class LicenseListCreateView(generics.ListCreateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class AdministratorListCreateView(generics.ListCreateAPIView):
    queryset = Administrator.objects.all()
    serializer_class = AdministratorSerializer
class LicenseListCreateView(generics.ListCreateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

# Add the following class
class LicenseDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer
# licenses/views.py
from rest_framework import generics
from .models import License
from .serializers import LicenseSerializer

class LicenseListCreateView(generics.ListCreateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

# Add the following classes
class ActivateLicenseView(generics.UpdateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class DeactivateLicenseView(generics.UpdateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class OfflineModeView(generics.UpdateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class AdministratorListView(generics.ListCreateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class RevokeLicenseView(generics.UpdateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class LoginView(generics.CreateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class LogoutView(generics.DestroyAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class UsageStatisticsView(generics.RetrieveAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class SecurityAuditLogView(generics.ListAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

class AlertsNotificationsView(generics.ListAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer
# licenses/views.py
from rest_framework import generics
from .models import License
from .serializers import LicenseSerializer
from rest_framework.response import Response
from rest_framework import status

class LicenseListCreateView(generics.ListCreateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
# licenses/views.py
from rest_framework import generics
from .models import License
from .serializers import LicenseSerializer

class OfflineModeView(generics.UpdateAPIView):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer
    lookup_url_kwarg = 'pk'  # Add this line

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)
