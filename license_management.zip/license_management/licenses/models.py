from django.db import models

# Create your models here.
from django.db import models

class License(models.Model):
    key = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Administrator(models.Model):
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=100)  # Use a secure password hashing method
    email = models.EmailField(unique=True)
    is_multi_factor_authenticated = models.BooleanField(default=False)
    role = models.CharField(max_length=20)  # Use Django's built-in User model for more features
