from django.urls import path
from .views import (
    LicenseListCreateView,
    LicenseDetailView,
    ActivateLicenseView,
    DeactivateLicenseView,
    OfflineModeView,
    AdministratorListView,
    RevokeLicenseView,
    LoginView,
    LogoutView,
    UsageStatisticsView,
    SecurityAuditLogView,
    AlertsNotificationsView,
)

urlpatterns = [
    # License Management
    path('licenses/', LicenseListCreateView.as_view(), name='license-list-create'),
    path('licenses/<int:pk>/', LicenseDetailView.as_view(), name='license-detail'),
    path('licenses/activate/', ActivateLicenseView.as_view(), name='activate-license'),
    path('licenses/deactivate/<int:pk>/', DeactivateLicenseView.as_view(), name='deactivate-license'),
    path('licenses/offline-mode/', OfflineModeView.as_view(), name='offline-mode'),

    # License Revocation
    path('revoke-license/<int:pk>/', RevokeLicenseView.as_view(), name='revoke-license'),

    # Administrator Management
    path('administrators/', AdministratorListView.as_view(), name='administrator-list'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),

    # Security
    path('usage-statistics/', UsageStatisticsView.as_view(), name='usage-statistics'),
    path('security-audit-log/', SecurityAuditLogView.as_view(), name='security-audit-log'),

    # Reporting and Monitoring
    path('alerts-notifications/', AlertsNotificationsView.as_view(), name='alerts-notifications'),
]
